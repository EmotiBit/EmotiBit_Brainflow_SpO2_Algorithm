# Innovo IP900AP
The Innovo IP900AP is a sensor designed to measure SPO2 (and heart rate).
## Data Collection Procedure
An AutoHotkey script was used to accept input from the user every two seconds which would then be saved to the EmotiBit as a user note through the EmotiBit oscilloscope. Therefore, there is only one file `EmotiBit.csv` which contains the IP900AP measured SPO2 levels every two seconds as user notes.